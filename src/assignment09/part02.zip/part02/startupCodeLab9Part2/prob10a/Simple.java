package assignment09.part02.startupCodeLab9Part2.prob10a;

public class Simple {
	boolean flag = false;
	Simple(boolean f) {
		flag = f;
	}
}
