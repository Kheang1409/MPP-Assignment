package assignment09.part02.startupCodeLab9Part2.prob10a;

import java.util.*;

public class Or {

	public static void main(String[] args) {
		List<Simple> list = Arrays.asList(new Simple(false), new Simple(false), new Simple(true));
		Or or = new Or();
		System.out.println(or.someSimpleIsTrue(list)); // This should print: true
	}

	public boolean someSimpleIsTrue(List<Simple> list) {
		return list.stream().anyMatch(s -> s.flag);
	}

}
