package assignment11;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class prob5 {

    public static void main(String[] args) {
        List<Integer> list = new ArrayList<Integer>();
        list.add(70);
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);
        list.add(60);
        Integer second = secondSmallest(list);
        System.out.println(second);

        List<String> studentNames = new ArrayList<>();
        studentNames.add("Hang Kheang");
        studentNames.add("Bishnu");
        studentNames.add("Pengleng");
        studentNames.add("Sarun");

        String secondName = secondSmallest(studentNames);
        System.out.println(secondName);

    }

    public static <T extends Comparable<? super T>> T secondSmallest(List<T> list) {
        T max = list.get(0);
        T secondMax = list.get(1);
        if(max.compareTo(secondMax) > 0){
            max = list.get(1);
            secondMax = list.get(0);
        }
        for(int i = 2; i < list.size(); i++){
            T temp = list.get(i);
            if(max.compareTo(temp) > 0){
                secondMax = max;
                max = temp;
            }
            else if(secondMax.compareTo(temp) > 0 && max.compareTo(temp) < 0){
                secondMax = temp;
            }
        }
        return secondMax;
    }
}
